# -*- coding: utf-8 -*-
# @Time    : 2018/11/18 16:22
# @Author  : MengnanChen
# @FileName: train_mlp.py
# @Software: PyCharm


import tensorflow as tf

class ValueWindow():
    def __init__(self, window_size=100):
        self._window_size = window_size
        self._values = []

    def append(self, x):
        self._values = self._values[-(self._window_size - 1):] + [x]

    @property
    def sum(self):
        return sum(self._values)

    @property
    def count(self):
        return len(self._values)

    @property
    def average(self):
        return self.sum / max(1, self.count)

    def reset(self):
        self._values = []


def add_train_stats(model):
    with tf.variable_scope('stats') as scope:
        tf.summary.scalar('loss',model.loss)
        tf.summary.scalar('learning_rate',model.learning_rate)

        return tf.summary.merge_all()

def add_eval_stats(summary_writer,step,loss,acc):
    values=[
        tf.Summary.Value(tag='eval_model/eval_stats/eval_loss',simple_value=loss),
        tf.Summary.Value(tag='eval_model/eval_stats/eval_acc',simple_value=acc)
    ]
    test_summary=tf.Summary(value=values)
    summary_writer.add_summary(test_summary,step)
