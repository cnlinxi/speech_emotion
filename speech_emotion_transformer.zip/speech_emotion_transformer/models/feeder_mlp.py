# -*- coding: utf-8 -*-
# @Time    : 2018/11/15 20:29
# @Author  : MengnanChen
# @FileName: feeder_mlp.py
# @Software: PyCharm

import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import pandas as pd

from models import hparams


class Feeder(object):
    def __init__(self, data_path):
        super(Feeder, self).__init__()
        self._data_path = data_path

        data = pd.read_csv(self._data_path)
        label_name = 'emolabel'
        data[label_name] = LabelEncoder().fit_transform(data[label_name])
        feature_column_names = [x for x in data.columns if x != 'emolabel']
        test_size = hparams.test_batch_size if hparams.test_batch_size is not None \
            else hparams.test_batch_size_percent
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(data[feature_column_names],
                                                                                data['emolabel'],
                                                                                test_size=test_size)

    def get_batch_data(self):
        num_batch = len(self.X_train) // hparams.batch_size

        X_train = tf.convert_to_tensor(self.X_train, tf.float32)
        y_train = tf.convert_to_tensor(self.y_train, tf.int32)

        input_queues = tf.train.slice_input_producer([X_train, y_train])
        x, y = tf.train.shuffle_batch(input_queues,
                                      num_threads=8,
                                      batch_size=hparams.batch_size,
                                      capacity=hparams.batch_size * 64,
                                      min_after_dequeue=hparams.batch_size * 32,
                                      allow_smaller_final_batch=False)
        return x, y, num_batch
